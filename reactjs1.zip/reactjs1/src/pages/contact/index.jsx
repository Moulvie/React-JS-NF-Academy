import Contacts from "../../components/shared/contact";





export default function Contact(){
    return(
        <>
            <Contacts/>
        </>
    )
}