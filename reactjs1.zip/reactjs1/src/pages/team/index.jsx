import Teams from "../../components/shared/team"

export default function Team(){
    return(
        <>
            <Teams/>
        </>
    )
}